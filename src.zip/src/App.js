import React from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Landing from './Components/Landing/Landing'
import Home from './Components/Landing/Home';
import About from './Components/Landing/About'
import Contact from './Components/Landing/Contact'
import Service from './Components/Landing/Services'
import Login from './Components/Landing/Login';

import Dashboard from './Components/Dashboard/Dashboard';
import Attendance from './Components/Dashboard/Attendance'
import Reports from './Components/Dashboard/Reports';
import Salary from './Components/Dashboard/Salary';
import Leave from './Components/Dashboard/Leave';
import PrivateRoute from './Components/Auth/PrivateRoutes';
import PublicRoute from './Components/Auth/PublicRoutes'

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<PublicRoute><Landing /></PublicRoute>}>
          <Route index element={<Home />}></Route>
          <Route path='about' element={<About />}></Route>
          <Route path='contact' element={<Contact />}></Route>
          <Route path='service' element={<Service />}></Route>
          <Route path='login' element={<Login />}></Route>
        </Route>

        <Route path='/dashboard' element={<PrivateRoute><Dashboard /></PrivateRoute>}>
          <Route index element={<Attendance />}></Route>
          <Route path='leave' element={<Leave />}></Route>
          <Route path='salary' element={<Salary />}></Route>
          <Route path='reports' element={<Reports />}></Route>
        </Route>
      </Routes>
    </BrowserRouter>
  )
}

export default App